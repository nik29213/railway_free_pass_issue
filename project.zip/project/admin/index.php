<?php
if(isset($_SESSION["admin_id"])){

  header("location:admin_home.php");
  exit();
}
 require_once "../db_con.php"; 
 $logerr = "";     
 if($conn)
 {
  if(isset($_POST["admin_login"])){
    $emp_id=$_POST['emp_id'];
    $password=md5($_POST['password']);
    if($emp_id=='' || $password=='')
    {
      $logerr = "email id and password both are required";
    }
    else
    {
      $query="SELECT * FROM admin WHERE username='$emp_id' AND password='$password'";
      $exec_query=mysqli_query($conn,$query);
      $s=mysqli_num_rows($exec_query);
      if($s>=1)
      {
        session_start();
        $_SESSION['admin_id']=$emp_id;
        header("location: admin_home.php");
      }
      else
      {
        $logerr = "either email id or password doesn't exist";
      }
    }
  }
 }
?>

<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
form {border: 3px solid #f1f1f1;}

input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 20%;
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}

img.avatar {
  width: 40%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 100px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
</style>
<!-- bootstrap cdn-->
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

<script type="text/javascript" src="https://code.jquery.com/jquery-1.8.2.min.js"></script>

</head>
<body>

  <center><h2>Login Form</h2></center>
  <div class ="container-fluid">
    <div class = "row">
      <div class = "col-sm-3"></div>
      <div class = "col-sm-6">
        <form action="" method="post">
          <div class="imgcontainer">
            <img src="img_avatar2.png" alt="Avatar" class="avatar">
          </div>

          <div class="container-fluid" style="background-size: "10px!impotant";>
            <label for="uname"><b>Username</b></label>
            <input type="text" class = "form-control" placeholder="Enter Username" name="emp_id" required>

            <label for="psw"><b>Password</b></label>
            <input type="password" class = "form-control" placeholder="Enter Password" name="password" required>
             <br /><br /> 
            <center><span style="color:red;"><?php echo($logerr); ?></span></center>
  
            <button type="submit"  value='login' name="admin_login">Login</button>
            <br />
            <label>
              <input type="checkbox" checked="checked" name="remember"> Remember me
            </label>
          </div>

          <div class="container-fluid" style="background-color:#f1f1f1">
            <span class="psw">Forgot <a href="#">password?</a></span><br /><br />
          </div>
        </form>
      </div>
      <div class = "col-sm-3"></div>

    </div>
  </div>
</body>
</html>
