<?php
$conn=mysqli_connect("localhost","root","","datapro");
if($conn) echo " "; 
?> 

